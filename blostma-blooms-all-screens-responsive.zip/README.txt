BLOSTMA BLOOMS — PREMIUM STOREFRONT

Open index.html in a modern browser.

Included:
- Premium boutique UI/UX rebuilt from scratch
- Exact supplied Blostma Blooms logo
- Responsive desktop/tablet/mobile layout
- Product cards with hover second-angle preview
- Amazon-style cursor-following image magnifier on product details
- Multi-angle product gallery
- Product video player with local demo video
- Product ratings/review UI
- Customer-photo review placeholders (clearly marked demo content)
- Wishlist using localStorage
- Persistent shopping bag using localStorage
- Quantity controls, shipping progress, WhatsApp ordering
- Custom-order email flow
- Search and category filtering

IMPORTANT FOR PRODUCTION:
Replace assets/products/*.svg with the real product photographs. The product gallery and zoom will automatically work with normal JPG/PNG product images as well.
Replace assets/blostma-demo-video.mp4 with each product's real video.
Connect checkout/payment, reviews, customer photo uploads, product inventory and order storage to your backend/payment provider before accepting real payments.
